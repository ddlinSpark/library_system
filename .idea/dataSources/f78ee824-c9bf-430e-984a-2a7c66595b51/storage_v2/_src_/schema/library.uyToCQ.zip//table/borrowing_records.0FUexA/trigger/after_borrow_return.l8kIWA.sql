create definer = root@localhost trigger after_borrow_return
    after update
    on borrowing_records
    for each row
BEGIN
    IF NEW.status = 'returned' AND OLD.status = 'borrowed' THEN
        UPDATE books 
        SET available_copies = available_copies + 1,
            status = 'available'
        WHERE book_id = NEW.book_id;
    END IF;
END;

