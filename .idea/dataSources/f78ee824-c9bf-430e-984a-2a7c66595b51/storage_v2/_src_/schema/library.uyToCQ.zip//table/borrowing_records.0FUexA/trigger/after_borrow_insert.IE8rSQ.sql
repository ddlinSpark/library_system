create definer = root@localhost trigger after_borrow_insert
    after insert
    on borrowing_records
    for each row
BEGIN
    UPDATE books 
    SET available_copies = available_copies - 1,
        status = CASE 
            WHEN available_copies - 1 = 0 THEN 'borrowed'
            ELSE status 
        END
    WHERE book_id = NEW.book_id;
END;

